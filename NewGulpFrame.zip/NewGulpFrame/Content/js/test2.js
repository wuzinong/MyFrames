function sss(){
	this.name = "test";
} 